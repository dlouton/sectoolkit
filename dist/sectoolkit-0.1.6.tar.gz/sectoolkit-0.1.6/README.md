# sectoolkit
Tools for working with Securities and Exchange Commission (SEC) indices and filings.
