__version__ = "0.1.6
"

# Import items from sub-modules into sectoolkit namespace
from .secmeta import (meta, headerfile)
from .secfiling import (filingDocument, filingArchive, ticker_dict, name_dict)